# 🔐 SheerID सत्यापन उपकरण

[![GitHub Stars](https://img.shields.io/github/stars/ThanhNguyxn/SheerID-Verification-Tool?style=social)](https://github.com/ThanhNguyxn/SheerID-Verification-Tool/stargazers)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![Documentation](https://img.shields.io/badge/Docs-Website-2ea44f?style=flat&logo=github&logoColor=white)](https://thanhnguyxn.github.io/SheerID-Verification-Tool/)

विभिन्न सेवाओं (Spotify, YouTube, Google One, आदि) के लिए SheerID सत्यापन वर्कफ़्लो को स्वचालित करने के लिए उपकरणों का एक व्यापक संग्रह।

---

## 🛠️ उपलब्ध उपकरण

| उपकरण | प्रकार | लक्ष्य | विवरण |
|------|------|--------|-------------|
| [spotify-verify-tool](../spotify-verify-tool/) | 🎵 छात्र | Spotify Premium | विश्वविद्यालय छात्र सत्यापन |
| [youtube-verify-tool](../youtube-verify-tool/) | 🎬 छात्र | YouTube Premium | विश्वविद्यालय छात्र सत्यापन |
| [one-verify-tool](../one-verify-tool/) | 🤖 छात्र | Gemini Advanced | Google One AI Premium सत्यापन |
| [boltnew-verify-tool](../boltnew-verify-tool/) | 👨‍🏫 शिक्षक | Bolt.new | शिक्षक सत्यापन (विश्वविद्यालय) |
| [canva-teacher-tool](../canva-teacher-tool/) | 🇬🇧 शिक्षक | Canva Education | यूके शिक्षक सत्यापन (K-12) |
| [k12-verify-tool](../k12-verify-tool/) | 🏫 K12 | ChatGPT Plus | K12 शिक्षक सत्यापन (हाई स्कूल) |
| [veterans-verify-tool](../veterans-verify-tool/) | 🎖️ सैन्य | सामान्य | सैन्य स्थिति सत्यापन |
| [veterans-extension](../veterans-extension/) | 🧩 Chrome | ब्राउज़र | सैन्य सत्यापन के लिए Chrome एक्सटेंशन |

### 🔗 बाहरी उपकरण

| उपकरण | प्रकार | विवरण |
|------|------|-------------|
| [RoxyBrowser](https://roxybrowser.com?code=01045PFA) | 🦊 ब्राउज़र | **एंटी-डिटेक्शन ब्राउज़र** — बिना बैन हुए कई सत्यापित खातों को सुरक्षित रूप से प्रबंधित करें |
| [Check IP](https://ip123.in/en?code=01045PFA) | 🌐 वेब | **IP जांचें** — अपना IP पता और प्रॉक्सी स्थिति जांचें |
| [SheerID Verification Bot](https://t.me/SheerID_Verification_bot?start=ref_LdPKPES3Ej) | 🤖 बॉट | स्वचालित Telegram सत्यापन बॉट |
| [Gmail Farmer Bot](https://t.me/GmailFarmerBot?start=7762497789) | 🤖 बॉट | Gmail खाते स्वचालित रूप से बनाएं |
| [GitHub Bot](https://t.me/AutoGHS_Bot?start=7762497789) | 🤖 बॉट | स्वचालित GitHub स्टार सेवा |
| [Student Card Generator](https://thanhnguyxn.github.io/student-card-generator/) | 🎓 उपकरण | मैनुअल सत्यापन के लिए छात्र कार्ड बनाएं |
| [Payslip Generator](https://thanhnguyxn.github.io/payslip-generator/) | 💰 उपकरण | शिक्षक सत्यापन के लिए वेतन पर्ची बनाएं |

---

## 🧠 कोर आर्किटेक्चर और लॉजिक

इस रिपॉजिटरी में सभी Python उपकरण उच्च सफलता दरों के लिए अनुकूलित एक सामान्य आर्किटेक्चर साझा करते हैं।

### 1. सत्यापन प्रवाह (The Verification Flow)
उपकरण एक मानकीकृत "वाटरफॉल" प्रक्रिया का पालन करते हैं:
1.  **डेटा जनरेशन (Data Generation)**: लक्षित जनसांख्यिकी से मेल खाने वाली एक यथार्थवादी पहचान (नाम, जन्म तिथि, ईमेल) बनाता है।
2.  **सबमिशन (`collectStudentPersonalInfo`)**: SheerID API को डेटा सबमिट करता है।
3.  **SSO स्किप (`DELETE /step/sso`)**: महत्वपूर्ण चरण। स्कूल पोर्टल में लॉग इन करने की आवश्यकता को बायपास करता है।
4.  **दस्तावेज़ अपलोड (`docUpload`)**: जनरेट किया गया प्रमाण दस्तावेज़ (छात्र आईडी, ट्रांसक्रिप्ट, या शिक्षक बैज) अपलोड करता है।
5.  **पूर्णता (`completeDocUpload`)**: SheerID को संकेत देता है कि अपलोड पूरा हो गया है।

### 2. बुद्धिमान रणनीतियाँ (Intelligent Strategies)

#### 🎓 विश्वविद्यालय रणनीति (Spotify, YouTube, Gemini)
- **भारित चयन**: **45+ विश्वविद्यालयों** (यूएस, वीएन, जेपी, केआर, आदि) की एक क्यूरेटेड सूची का उपयोग करता है।
- **सफलता ट्रैकिंग**: उच्च सफलता दरों वाले विश्वविद्यालय अधिक बार चुने जाते हैं।
- **दस्तावेज़ जनरेशन**: गतिशील नामों और तारीखों के साथ यथार्थवादी छात्र आईडी कार्ड जनरेट करता है।

#### 👨‍🏫 शिक्षक रणनीति (Bolt.new)
- **आयु लक्ष्यीकरण**: शिक्षक जनसांख्यिकी से मेल खाने के लिए बड़ी उम्र (25-55 वर्ष) की पहचान जनरेट करता है।
- **दस्तावेज़ जनरेशन**: छात्र आईडी के बजाय "रोजगार प्रमाणपत्र" बनाता है।
- **एंडपॉइंट**: छात्र एंडपॉइंट के बजाय `collectTeacherPersonalInfo` को लक्षित करता है।

#### 🏫 K12 रणनीति (ChatGPT Plus)
- **स्कूल प्रकार लक्ष्यीकरण**: विशेष रूप से `type: "K12"` (न कि `HIGH_SCHOOL`) वाले स्कूलों को लक्षित करता है।
- **ऑटो-पास लॉजिक**: यदि स्कूल और शिक्षक की जानकारी मेल खाती है तो K12 सत्यापन अक्सर दस्तावेज़ अपलोड के बिना **स्वचालित रूप से स्वीकृत** हो जाता है।
- **फॉलबैक**: यदि अपलोड की आवश्यकता है, तो यह शिक्षक बैज जनरेट करता है।

#### 🎖️ वेटरन्स रणनीति (ChatGPT Plus)
- **सख्त पात्रता**: सक्रिय ड्यूटी सैन्य या **पिछले 12 महीनों** में सेवानिवृत्त वेटरन्स को लक्षित करता है।
- **आधिकारिक जांच**: SheerID DoD/DEERS डेटाबेस के विरुद्ध सत्यापित करता है।
- **लॉजिक**: स्वचालित अनुमोदन की संभावनाओं को अधिकतम करने के लिए डिफ़ॉल्ट रूप से हाल की सेवानिवृत्ति तिथियां उपयोग करता है।

#### 🛡️ एंटी-डिटेक्शन मॉड्यूल
सभी उपकरणों में अब `anti_detect.py` शामिल है जो प्रदान करता है:
- **रैंडम User-Agents**: 10+ वास्तविक ब्राउज़र UA स्ट्रिंग्स (Chrome, Firefox, Edge, Safari)
- **ब्राउज़र-जैसे हेडर**: उचित `sec-ch-ua`, `Accept-Language`, आदि।
- **TLS फिंगरप्रिंट स्पूफिंग**: Chrome के JA3/JA4 फिंगरप्रिंट की नकल करने के लिए `curl_cffi` का उपयोग करता है
- **रैंडम विलंब**: मानव व्यवहार की नकल करने के लिए गामा वितरण समय
- **स्मार्ट सेशन**: सर्वोत्तम उपलब्ध HTTP लाइब्रेरी का स्वचालित चयन (curl_cffi > cloudscraper > httpx > requests)
- **NewRelic हेडर**: SheerID API कॉल के लिए आवश्यक ट्रैकिंग हेडर
- **सेशन वार्मिंग**: वैध ब्राउज़र सेशन स्थापित करने के लिए पूर्व-सत्यापन अनुरोध
- **ईमेल जनरेशन**: विश्वविद्यालय डोमेन से मेल खाने वाले यथार्थवादी छात्र ईमेल बनाता है
- **प्रॉक्सी जियो-मैचिंग**: संगति के लिए प्रॉक्सी स्थान को विश्वविद्यालय के देश से मिलाता है
- **मल्टी-ब्राउज़र इम्पर्सनेशन**: Chrome, Edge, और Safari फिंगरप्रिंट के बीच रोटेट करता है

#### 📄 दस्तावेज़ जनरेशन मॉड्यूल
नया `doc_generator.py` जनरेट किए गए दस्तावेज़ों के लिए एंटी-डिटेक्शन प्रदान करता है:
- **नॉइज़ इंजेक्शन**: टेम्पलेट डिटेक्शन से बचने के लिए रैंडम पिक्सेल नॉइज़
- **रंग भिन्नता**: विशिष्टता के लिए 6 अलग-अलग रंग योजनाएं
- **डायनामिक पोजिशनिंग**: तत्व स्थितियों पर ±3px भिन्नता
- **एकाधिक प्रकार**: छात्र आईडी, ट्रांसक्रिप्ट, शिक्षक बैज
- **यथार्थवादी विवरण**: रैंडम बारकोड, QR कोड, कोर्स ग्रेड

> [!WARNING]
> **API-आधारित उपकरणों की अंतर्निहित सीमाएं हैं**
>
> SheerID उन्नत डिटेक्शन का उपयोग करता है जिसमें शामिल हैं:
> - **TLS फिंगरप्रिंटिंग**: Python `requests`/`httpx` में पहचान योग्य सिग्नेचर हैं
> - **सिग्नल इंटेलिजेंस**: IP पता, डिवाइस विशेषताएं, ईमेल आयु विश्लेषण
> - **AI दस्तावेज़ समीक्षा**: जाली/टेम्पलेट दस्तावेज़ों का पता लगाता है
>
> सर्वोत्तम परिणामों के लिए: **रेजिडेंशियल प्रॉक्सी** + TLS स्पूफिंग के लिए `curl_cffi` इंस्टॉल करें।
> ब्राउज़र एक्सटेंशन आमतौर पर API उपकरणों की तुलना में उच्च सफलता दर रखते हैं।

> [!IMPORTANT]
> **Gemini/Google One केवल US में है (जनवरी 2026 से)**
>
> `one-verify-tool` केवल US IP के साथ काम करता है। अंतर्राष्ट्रीय उपयोगकर्ताओं को सत्यापन विफलताएं दिखाई देंगी।

---

## 📋 त्वरित शुरुआत

### पूर्वापेक्षाएँ
- Python 3.8+
- `pip`

### इंस्टॉलेशन

1.  **रिपॉजिटरी क्लोन करें:**
    ```bash
    git clone https://github.com/ThanhNguyxn/SheerID-Verification-Tool.git
    cd SheerID-Verification-Tool
    ```

2.  **डिपेंडेंसी इंस्टॉल करें:**
    ```bash
    pip install httpx Pillow
    ```

3.  **[वैकल्पिक] उन्नत एंटी-डिटेक्शन:**
    ```bash
    pip install curl_cffi cloudscraper
    ```
    - `curl_cffi`: TLS फिंगरप्रिंट (JA3/JA4) को असली Chrome जैसा दिखने के लिए स्पूफ करता है
    - `cloudscraper`: Cloudflare सुरक्षा को बायपास करता है

4.  **उपकरण चलाएं (जैसे: Spotify):**
    ```bash
    cd spotify-verify-tool
    python main.py "YOUR_SHEERID_URL"
    ```

---

## 🦊 आधिकारिक पार्टनर: RoxyBrowser

🛡 **एंटी-डिटेक्शन सुरक्षा** — प्रत्येक खाते के लिए अद्वितीय फिंगरप्रिंट, विभिन्न वास्तविक उपकरणों जैसे दिखते हैं।

📉 **लिंकेज रोकें** — SheerID और प्लेटफॉर्म को आपके खातों को जोड़ने से रोकता है।

🚀 **बल्क उपयोगकर्ताओं के लिए आदर्श** — सुरक्षित रूप से सैकड़ों सत्यापित खातों का प्रबंधन करें।

[![मुफ्त में आज़माएं](https://img.shields.io/badge/मुफ्त%20में%20आज़माएं-RoxyBrowser-ff6b35?style=for-the-badge&logo=googlechrome&logoColor=white)](https://roxybrowser.com?code=01045PFA)

---

## ⚠️ अस्वीकरण

यह प्रोजेक्ट केवल **शैक्षिक उद्देश्यों** के लिए है। उपकरण प्रदर्शित करते हैं कि सत्यापन प्रणालियाँ कैसे काम करती हैं और उनका परीक्षण कैसे किया जा सकता है।
- धोखाधड़ी के उद्देश्यों के लिए उपयोग न करें।
- लेखक किसी भी दुरुपयोग के लिए जिम्मेदार नहीं हैं।
- सभी प्लेटफॉर्म की सेवा की शर्तों का सम्मान करें।

---

## 🤝 योगदान

योगदान का स्वागत है! कृपया Pull Request सबमिट करने में संकोच न करें।

---

## ❤️ समर्थन

यदि आपको यह प्रोजेक्ट उपयोगी लगता है, तो मुझे समर्थन देने पर विचार करें:

[![GitHub Sponsors](https://img.shields.io/badge/Sponsor-GitHub-ea4aaa?style=for-the-badge&logo=github)](https://github.com/sponsors/ThanhNguyxn)
[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-FFDD00?style=for-the-badge&logo=buy-me-a-coffee&logoColor=black)](https://buymeacoffee.com/thanhnguyxn)

---

## 🌐 भाषाएं

| 🇺🇸 [English](../README.md) | 🇻🇳 [Tiếng Việt](./README.vi.md) | 🇨🇳 [中文](./README.zh.md) | 🇯🇵 [日本語](./README.ja.md) | 🇰🇷 [한국어](./README.ko.md) |
|:---:|:---:|:---:|:---:|:---:|
| 🇪🇸 [Español](./README.es.md) | 🇫🇷 [Français](./README.fr.md) | 🇩🇪 [Deutsch](./README.de.md) | 🇧🇷 [Português](./README.pt-BR.md) | 🇷🇺 [Русский](./README.ru.md) |
| 🇸🇦 [العربية](./README.ar.md) | 🇮🇳 [हिन्दी](./README.hi.md) | 🇹🇭 [ไทย](./README.th.md) | 🇹🇷 [Türkçe](./README.tr.md) | 🇵🇱 [Polski](./README.pl.md) |
| 🇮🇹 [Italiano](./README.it.md) | 🇮🇩 [Bahasa Indonesia](./README.id.md) | | | |

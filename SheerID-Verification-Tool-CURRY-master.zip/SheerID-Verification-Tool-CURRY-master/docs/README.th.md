# 🔐 เครื่องมือยืนยันตัวตน SheerID

[![GitHub Stars](https://img.shields.io/github/stars/ThanhNguyxn/SheerID-Verification-Tool?style=social)](https://github.com/ThanhNguyxn/SheerID-Verification-Tool/stargazers)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![Documentation](https://img.shields.io/badge/Docs-Website-2ea44f?style=flat&logo=github&logoColor=white)](https://thanhnguyxn.github.io/SheerID-Verification-Tool/)

ชุดเครื่องมือครอบคลุมสำหรับอัตโนมัติเวิร์กโฟลว์การยืนยัน SheerID สำหรับบริการต่างๆ

---

## 🛠️ เครื่องมือที่มี

| เครื่องมือ | ประเภท | เป้าหมาย | คำอธิบาย |
|------|------|--------|-------------|
| [spotify-verify-tool](../spotify-verify-tool/) | 🎵 นักศึกษา | Spotify Premium | การยืนยันนักศึกษา |
| [youtube-verify-tool](../youtube-verify-tool/) | 🎬 นักศึกษา | YouTube Premium | การยืนยันนักศึกษา |
| [one-verify-tool](../one-verify-tool/) | 🤖 นักศึกษา | Gemini Advanced | การยืนยัน Google One |
| [boltnew-verify-tool](../boltnew-verify-tool/) | 👨‍🏫 ครู | Bolt.new | การยืนยันครู |
| [canva-teacher-tool](../canva-teacher-tool/) | 🇬🇧 ครู | Canva Education | การยืนยันครู UK |
| [k12-verify-tool](../k12-verify-tool/) | 🏫 K12 | ChatGPT Plus | การยืนยันครู K12 |
| [veterans-verify-tool](../veterans-verify-tool/) | 🎖️ ทหาร | ทั่วไป | การยืนยันสถานะทหาร |
| [veterans-extension](../veterans-extension/) | 🧩 Chrome | เบราว์เซอร์ | ส่วนขยาย Chrome |

### 🔗 เครื่องมือภายนอก

| เครื่องมือ | ประเภท | คำอธิบาย |
|------|------|-------------|
| [RoxyBrowser](https://roxybrowser.com?code=01045PFA) | 🦊 เบราว์เซอร์ | **เบราว์เซอร์ป้องกันการตรวจจับ** |
| [Check IP](https://ip123.in/en?code=01045PFA) | 🌐 เว็บ | **ตรวจสอบ IP** |
| [SheerID Verification Bot](https://t.me/SheerID_Verification_bot?start=ref_LdPKPES3Ej) | 🤖 บอท | บอท Telegram |
| [Gmail Farmer Bot](https://t.me/GmailFarmerBot?start=7762497789) | 🤖 บอท | สร้างบัญชี Gmail อัตโนมัติ |
| [GitHub Bot](https://t.me/AutoGHS_Bot?start=7762497789) | 🤖 บอท | บริการดาว GitHub อัตโนมัติ |
| [Student Card Generator](https://thanhnguyxn.github.io/student-card-generator/) | 🎓 เครื่องมือ | สร้างบัตรนักศึกษา |
| [Payslip Generator](https://thanhnguyxn.github.io/payslip-generator/) | 💰 เครื่องมือ | สร้างสลิปเงินเดือน |

---

## 🧠 สถาปัตยกรรมหลัก

### 1. กระแสการยืนยัน
1. **การสร้างข้อมูล**: สร้างตัวตนที่สมจริง
2. **การส่ง**: ส่งข้อมูลไปยัง SheerID API
3. **ข้าม SSO**: ข้ามข้อกำหนดเข้าสู่ระบบ
4. **อัปโหลดเอกสาร**: อัปโหลดเอกสารพิสูจน์
5. **เสร็จสิ้น**: ส่งสัญญาณว่าอัปโหลดเสร็จ

### 2. กลยุทธ์อัจฉริยะ

#### 🎓 กลยุทธ์มหาวิทยาลัย
- ใช้รายการ **45+ มหาวิทยาลัย**
- มหาวิทยาลัยที่ประสบความสำเร็จสูงถูกเลือกบ่อยกว่า
- สร้างบัตรนักศึกษาที่สมจริง

#### 👨‍🏫 กลยุทธ์ครู
- สร้างตัวตนอายุ 25-55 ปี
- สร้าง "หนังสือรับรองการจ้างงาน"

#### 🏫 กลยุทธ์ K12
- กำหนดเป้าหมายโรงเรียน K12
- มักอนุมัติอัตโนมัติ

#### 🎖️ กลยุทธ์ทหารผ่านศึก
- ทหารประจำการหรือปลดประจำการใน 12 เดือน
- ตรวจสอบกับฐานข้อมูล DoD/DEERS

#### 🛡️ โมดูลป้องกันการตรวจจับ
- User-Agents แบบสุ่ม
- การปลอม TLS Fingerprint
- การหน่วงเวลาแบบสุ่ม
- การสร้างอีเมลที่สมจริง

#### 📄 โมดูลสร้างเอกสาร
- การฉีดสัญญาณรบกวน
- ความหลากหลายของสี
- การวางตำแหน่งแบบไดนามิก

> [!WARNING]
> **เครื่องมือ API มีข้อจำกัด** - ใช้พร็อกซี่ที่อยู่อาศัย + `curl_cffi`

> [!IMPORTANT]
> **Gemini/Google One ใช้ได้เฉพาะสหรัฐอเมริกา (ตั้งแต่มกราคม 2026)**

---

## 📋 เริ่มต้นอย่างรวดเร็ว

```bash
git clone https://github.com/ThanhNguyxn/SheerID-Verification-Tool.git
cd SheerID-Verification-Tool
pip install httpx Pillow
pip install curl_cffi cloudscraper  # ทางเลือก
cd spotify-verify-tool
python main.py "YOUR_SHEERID_URL"
```

---

## 🦊 พันธมิตร: RoxyBrowser

[![ทดลองฟรี](https://img.shields.io/badge/ทดลองฟรี-RoxyBrowser-ff6b35?style=for-the-badge&logo=googlechrome&logoColor=white)](https://roxybrowser.com?code=01045PFA)

---

## ⚠️ ข้อจำกัดความรับผิดชอบ

โปรเจกต์นี้มีไว้สำหรับ**วัตถุประสงค์ทางการศึกษาเท่านั้น**

---

## ❤️ สนับสนุน

[![GitHub Sponsors](https://img.shields.io/badge/Sponsor-GitHub-ea4aaa?style=for-the-badge&logo=github)](https://github.com/sponsors/ThanhNguyxn)
[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-FFDD00?style=for-the-badge&logo=buy-me-a-coffee&logoColor=black)](https://buymeacoffee.com/thanhnguyxn)

---

## 🌐 ภาษา

| 🇺🇸 [English](../README.md) | 🇻🇳 [Tiếng Việt](./README.vi.md) | 🇨🇳 [中文](./README.zh.md) | 🇯🇵 [日本語](./README.ja.md) | 🇰🇷 [한국어](./README.ko.md) |
|:---:|:---:|:---:|:---:|:---:|
| 🇪🇸 [Español](./README.es.md) | 🇫🇷 [Français](./README.fr.md) | 🇩🇪 [Deutsch](./README.de.md) | 🇧🇷 [Português](./README.pt-BR.md) | 🇷🇺 [Русский](./README.ru.md) |
| 🇸🇦 [العربية](./README.ar.md) | 🇮🇳 [हिन्दी](./README.hi.md) | 🇹🇭 [ไทย](./README.th.md) | 🇹🇷 [Türkçe](./README.tr.md) | 🇵🇱 [Polski](./README.pl.md) |
| 🇮🇹 [Italiano](./README.it.md) | 🇮🇩 [Bahasa Indonesia](./README.id.md) | | | |

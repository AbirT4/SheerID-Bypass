# 🔐 أداة التحقق من SheerID

[![GitHub Stars](https://img.shields.io/github/stars/ThanhNguyxn/SheerID-Verification-Tool?style=social)](https://github.com/ThanhNguyxn/SheerID-Verification-Tool/stargazers)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![Documentation](https://img.shields.io/badge/Docs-Website-2ea44f?style=flat&logo=github&logoColor=white)](https://thanhnguyxn.github.io/SheerID-Verification-Tool/)

مجموعة شاملة من الأدوات لأتمتة سير عمل التحقق من SheerID لخدمات متنوعة (Spotify، YouTube، Google One، إلخ).

---

## 🛠️ الأدوات المتاحة

| الأداة | النوع | الهدف | الوصف |
|------|------|--------|-------------|
| [spotify-verify-tool](../spotify-verify-tool/) | 🎵 طالب | Spotify Premium | التحقق من طلاب الجامعة |
| [youtube-verify-tool](../youtube-verify-tool/) | 🎬 طالب | YouTube Premium | التحقق من طلاب الجامعة |
| [one-verify-tool](../one-verify-tool/) | 🤖 طالب | Gemini Advanced | التحقق من Google One AI Premium |
| [boltnew-verify-tool](../boltnew-verify-tool/) | 👨‍🏫 معلم | Bolt.new | التحقق من المعلمين (الجامعة) |
| [canva-teacher-tool](../canva-teacher-tool/) | 🇬🇧 معلم | Canva Education | التحقق من معلمي المملكة المتحدة (K-12) |
| [k12-verify-tool](../k12-verify-tool/) | 🏫 K12 | ChatGPT Plus | التحقق من معلمي K12 (المدرسة الثانوية) |
| [veterans-verify-tool](../veterans-verify-tool/) | 🎖️ عسكري | عام | التحقق من الحالة العسكرية |
| [veterans-extension](../veterans-extension/) | 🧩 Chrome | متصفح | إضافة Chrome للتحقق العسكري |

### 🔗 أدوات خارجية

| الأداة | النوع | الوصف |
|------|------|-------------|
| [RoxyBrowser](https://roxybrowser.com?code=01045PFA) | 🦊 متصفح | **متصفح مضاد للكشف** — إدارة حسابات متعددة موثقة بأمان دون حظر |
| [Check IP](https://ip123.in/en?code=01045PFA) | 🌐 ويب | **فحص IP** — تحقق من عنوان IP الخاص بك وحالة البروكسي |
| [SheerID Verification Bot](https://t.me/SheerID_Verification_bot?start=ref_LdPKPES3Ej) | 🤖 بوت | بوت تيليجرام للتحقق الآلي |
| [Gmail Farmer Bot](https://t.me/GmailFarmerBot?start=7762497789) | 🤖 بوت | إنشاء حسابات Gmail تلقائياً |
| [GitHub Bot](https://t.me/AutoGHS_Bot?start=7762497789) | 🤖 بوت | خدمة نجوم GitHub تلقائية |
| [Student Card Generator](https://thanhnguyxn.github.io/student-card-generator/) | 🎓 أداة | إنشاء بطاقات طلابية للتحقق اليدوي |
| [Payslip Generator](https://thanhnguyxn.github.io/payslip-generator/) | 💰 أداة | إنشاء قسائم الرواتب للتحقق من المعلمين |

---

## 🧠 البنية الأساسية والمنطق

تشترك جميع أدوات Python في هذا المستودع في بنية مشتركة محسنة لتحقيق معدلات نجاح عالية.

### 1. تدفق التحقق (The Verification Flow)
تتبع الأدوات عملية "الشلال" المعيارية:
1.  **توليد البيانات (Data Generation)**: إنشاء هوية واقعية (الاسم، تاريخ الميلاد، البريد الإلكتروني) تتطابق مع الفئة الديموغرافية المستهدفة.
2.  **الإرسال (`collectStudentPersonalInfo`)**: إرسال البيانات إلى واجهة برمجة تطبيقات SheerID.
3.  **تخطي SSO (`DELETE /step/sso`)**: خطوة حاسمة. تجاوز متطلبات تسجيل الدخول إلى بوابة المدرسة.
4.  **تحميل المستند (`docUpload`)**: تحميل مستند إثبات مُنشأ (هوية طالب، نص درجات، أو شارة معلم).
5.  **الإكمال (`completeDocUpload`)**: إشارة إلى SheerID بأن التحميل قد اكتمل.

### 2. استراتيجيات ذكية (Intelligent Strategies)

#### 🎓 استراتيجية الجامعة (Spotify، YouTube، Gemini)
- **اختيار مرجح**: يستخدم قائمة منتقاة من **45+ جامعة** (الولايات المتحدة، فيتنام، اليابان، كوريا، إلخ).
- **تتبع النجاح**: يتم اختيار الجامعات ذات معدلات النجاح الأعلى بشكل متكرر.
- **توليد المستندات**: توليد بطاقات هوية طلابية واقعية بأسماء وتواريخ ديناميكية.

#### 👨‍🏫 استراتيجية المعلم (Bolt.new)
- **استهداف العمر**: توليد هويات أكبر سناً (25-55 عاماً) لتتناسب مع ديموغرافية المعلمين.
- **توليد المستندات**: إنشاء "شهادات التوظيف" بدلاً من هويات الطلاب.
- **نقطة النهاية**: استهداف `collectTeacherPersonalInfo` بدلاً من نقاط نهاية الطلاب.

#### 🏫 استراتيجية K12 (ChatGPT Plus)
- **استهداف نوع المدرسة**: استهداف محدد للمدارس ذات `type: "K12"` (وليس `HIGH_SCHOOL`).
- **منطق الموافقة التلقائية (Auto-Pass)**: غالباً ما تتم **الموافقة تلقائياً** على التحقق من K12 دون تحميل مستندات إذا تطابقت معلومات المدرسة والمعلم.
- **البديل**: إذا كان التحميل مطلوباً، يتم إنشاء شارة معلم.

#### 🎖️ استراتيجية المحاربين القدامى (ChatGPT Plus)
- **أهلية صارمة**: استهداف العسكريين في الخدمة الفعلية أو المحاربين القدامى المنفصلين خلال **آخر 12 شهراً**.
- **فحص رسمي**: يتحقق SheerID من قاعدة بيانات DoD/DEERS.
- **المنطق**: يستخدم افتراضياً تواريخ التسريح الحديثة لتعظيم فرص الموافقة التلقائية.

#### 🛡️ وحدة مكافحة الكشف
تتضمن جميع الأدوات الآن `anti_detect.py` الذي يوفر:
- **User-Agents عشوائية**: 10+ سلاسل UA لمتصفحات حقيقية (Chrome، Firefox، Edge، Safari)
- **رؤوس شبيهة بالمتصفح**: `sec-ch-ua`، `Accept-Language` صحيحة، إلخ.
- **انتحال بصمة TLS**: يستخدم `curl_cffi` لمحاكاة بصمة JA3/JA4 الخاصة بـ Chrome
- **تأخيرات عشوائية**: توقيت توزيع جاما لمحاكاة السلوك البشري
- **جلسة ذكية**: تحديد أفضل مكتبة HTTP متاحة تلقائياً (curl_cffi > cloudscraper > httpx > requests)
- **رؤوس NewRelic**: رؤوس التتبع المطلوبة لاستدعاءات API الخاصة بـ SheerID
- **تسخين الجلسة**: طلبات ما قبل التحقق لإنشاء جلسة متصفح شرعية
- **توليد البريد الإلكتروني**: إنشاء رسائل بريد إلكتروني طلابية واقعية تتطابق مع نطاقات الجامعة
- **مطابقة جغرافية للبروكسي**: مطابقة موقع البروكسي مع بلد الجامعة للاتساق
- **انتحال متعدد المتصفحات**: التناوب بين بصمات Chrome وEdge وSafari

#### 📄 وحدة توليد المستندات
يوفر `doc_generator.py` الجديد مكافحة الكشف للمستندات المُنشأة:
- **حقن الضوضاء**: ضوضاء بكسل عشوائية لتجنب اكتشاف القوالب
- **تنوع الألوان**: 6 مخططات ألوان مختلفة للتفرد
- **تحديد المواقع الديناميكي**: تباين ±3 بكسل في مواضع العناصر
- **أنواع متعددة**: هوية الطالب، نص الدرجات، شارة المعلم
- **تفاصيل واقعية**: رموز شريطية عشوائية، رموز QR، درجات المقررات

> [!WARNING]
> **الأدوات المستندة إلى API لها قيود متأصلة**
>
> يستخدم SheerID كشفاً متقدماً يشمل:
> - **بصمة TLS**: Python `requests`/`httpx` لها توقيعات قابلة للاكتشاف
> - **استخبارات الإشارات**: عنوان IP، سمات الجهاز، تحليل عمر البريد الإلكتروني
> - **مراجعة المستندات بالذكاء الاصطناعي**: اكتشاف المستندات المزورة/القوالب
>
> للحصول على أفضل النتائج: استخدم **بروكسيات سكنية** + قم بتثبيت `curl_cffi` لانتحال TLS.
> عادةً ما تحقق إضافات المتصفح معدلات نجاح أعلى من أدوات API.

> [!IMPORTANT]
> **Gemini/Google One للولايات المتحدة فقط (منذ يناير 2026)**
>
> يعمل `one-verify-tool` فقط مع عناوين IP الأمريكية. سيرى المستخدمون الدوليون فشل التحقق.

---

## 📋 البدء السريع

### المتطلبات المسبقة
- Python 3.8+
- `pip`

### التثبيت

1.  **استنساخ المستودع:**
    ```bash
    git clone https://github.com/ThanhNguyxn/SheerID-Verification-Tool.git
    cd SheerID-Verification-Tool
    ```

2.  **تثبيت التبعيات:**
    ```bash
    pip install httpx Pillow
    ```

3.  **[اختياري] مكافحة الكشف المحسّنة:**
    ```bash
    pip install curl_cffi cloudscraper
    ```
    - `curl_cffi`: ينتحل بصمة TLS (JA3/JA4) ليبدو مثل Chrome الحقيقي
    - `cloudscraper`: يتجاوز حماية Cloudflare

4.  **تشغيل أداة (مثال: Spotify):**
    ```bash
    cd spotify-verify-tool
    python main.py "YOUR_SHEERID_URL"
    ```

---

## 🦊 الشريك الرسمي: RoxyBrowser

🛡 **حماية مضادة للكشف** — بصمة فريدة لكل حساب، تبدو كأجهزة حقيقية مختلفة.

📉 **منع الربط** — يمنع SheerID والمنصات من ربط حساباتك.

🚀 **مثالي للمستخدمين بالجملة** — إدارة آمنة لمئات الحسابات الموثقة.

[![تجربة مجانية](https://img.shields.io/badge/تجربة%20مجانية-RoxyBrowser-ff6b35?style=for-the-badge&logo=googlechrome&logoColor=white)](https://roxybrowser.com?code=01045PFA)

---

## ⚠️ إخلاء المسؤولية

هذا المشروع مخصص **للأغراض التعليمية فقط**. توضح الأدوات كيفية عمل أنظمة التحقق وكيف يمكن اختبارها.
- لا تستخدم لأغراض احتيالية.
- المؤلفون غير مسؤولين عن أي سوء استخدام.
- احترم شروط الخدمة لجميع المنصات.

---

## 🤝 المساهمة

نرحب بالمساهمات! لا تتردد في تقديم طلب سحب.

---

## ❤️ الدعم

إذا وجدت هذا المشروع مفيداً، فكر في دعمي:

[![GitHub Sponsors](https://img.shields.io/badge/Sponsor-GitHub-ea4aaa?style=for-the-badge&logo=github)](https://github.com/sponsors/ThanhNguyxn)
[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-FFDD00?style=for-the-badge&logo=buy-me-a-coffee&logoColor=black)](https://buymeacoffee.com/thanhnguyxn)

---

## 🌐 اللغات

| 🇺🇸 [English](../README.md) | 🇻🇳 [Tiếng Việt](./README.vi.md) | 🇨🇳 [中文](./README.zh.md) | 🇯🇵 [日本語](./README.ja.md) | 🇰🇷 [한국어](./README.ko.md) |
|:---:|:---:|:---:|:---:|:---:|
| 🇪🇸 [Español](./README.es.md) | 🇫🇷 [Français](./README.fr.md) | 🇩🇪 [Deutsch](./README.de.md) | 🇧🇷 [Português](./README.pt-BR.md) | 🇷🇺 [Русский](./README.ru.md) |
| 🇸🇦 [العربية](./README.ar.md) | 🇮🇳 [हिन्दी](./README.hi.md) | 🇹🇭 [ไทย](./README.th.md) | 🇹🇷 [Türkçe](./README.tr.md) | 🇵🇱 [Polski](./README.pl.md) |
| 🇮🇹 [Italiano](./README.it.md) | 🇮🇩 [Bahasa Indonesia](./README.id.md) | | | |

# 🔐 Herramienta de Verificación SheerID

[![GitHub Stars](https://img.shields.io/github/stars/ThanhNguyxn/SheerID-Verification-Tool?style=social)](https://github.com/ThanhNguyxn/SheerID-Verification-Tool/stargazers)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![Documentation](https://img.shields.io/badge/Docs-Website-2ea44f?style=flat&logo=github&logoColor=white)](https://thanhnguyxn.github.io/SheerID-Verification-Tool/)

Una colección completa de herramientas para automatizar los flujos de trabajo de verificación de SheerID para varios servicios (Spotify, YouTube, Google One, etc.).

---

## 🛠️ Herramientas Disponibles

| Herramienta | Tipo | Objetivo | Descripción |
|------|------|--------|-------------|
| [spotify-verify-tool](../spotify-verify-tool/) | 🎵 Estudiante | Spotify Premium | Verificación de estudiantes universitarios |
| [youtube-verify-tool](../youtube-verify-tool/) | 🎬 Estudiante | YouTube Premium | Verificación de estudiantes universitarios |
| [one-verify-tool](../one-verify-tool/) | 🤖 Estudiante | Gemini Advanced | Verificación de Google One AI Premium |
| [boltnew-verify-tool](../boltnew-verify-tool/) | 👨‍🏫 Profesor | Bolt.new | Verificación de profesores (Universidad) |
| [canva-teacher-tool](../canva-teacher-tool/) | 🇬🇧 Profesor | Canva Education | Verificación de profesores del Reino Unido (K-12) |
| [k12-verify-tool](../k12-verify-tool/) | 🏫 K12 | ChatGPT Plus | Verificación de profesores K12 (Escuela Secundaria) |
| [veterans-verify-tool](../veterans-verify-tool/) | 🎖️ Militar | General | Verificación de estatus militar |
| [veterans-extension](../veterans-extension/) | 🧩 Chrome | Navegador | Extensión de Chrome para verificación militar |

### 🔗 Herramientas Externas

| Herramienta | Tipo | Descripción |
|------|------|-------------|
| [RoxyBrowser](https://roxybrowser.com?code=01045PFA) | 🦊 Navegador | **Navegador anti-detección** — Gestione múltiples cuentas verificadas sin ser baneado |
| [Check IP](https://ip123.in/en?code=01045PFA) | 🌐 Web | **Verificar IP** — Compruebe su dirección IP y estado del proxy |
| [SheerID Verification Bot](https://t.me/SheerID_Verification_bot?start=ref_LdPKPES3Ej) | 🤖 Bot | Bot de Telegram de verificación automatizado |
| [Gmail Farmer Bot](https://t.me/GmailFarmerBot?start=7762497789) | 🤖 Bot | Crea cuentas de Gmail automáticamente |
| [GitHub Bot](https://t.me/AutoGHS_Bot?start=7762497789) | 🤖 Bot | Servicio automático de estrellas GitHub |
| [Student Card Generator](https://thanhnguyxn.github.io/student-card-generator/) | 🎓 Herramienta | Crear tarjetas de estudiante para verificación manual |
| [Payslip Generator](https://thanhnguyxn.github.io/payslip-generator/) | 💰 Herramienta | Generar nóminas para verificación de profesores |

---

## 🧠 Arquitectura y Lógica Principal

Todas las herramientas Python en este repositorio comparten una arquitectura común optimizada para altas tasas de éxito.

### 1. El Flujo de Verificación (The Verification Flow)
Las herramientas siguen un proceso estandarizado de "Cascada":
1.  **Generación de Datos (Data Generation)**: Crea una identidad realista (Nombre, Fecha de nacimiento, Email) que coincide con el grupo demográfico objetivo.
2.  **Envío (`collectStudentPersonalInfo`)**: Envía datos a la API de SheerID.
3.  **Omitir SSO (`DELETE /step/sso`)**: Paso crucial. Omite el requisito de iniciar sesión en un portal escolar.
4.  **Carga de Documentos (`docUpload`)**: Carga un documento de prueba generado (ID de estudiante, Transcripción o Insignia de profesor).
5.  **Finalización (`completeDocUpload`)**: Señala a SheerID que la carga ha finalizado.

### 2. Estrategias Inteligentes (Intelligent Strategies)

#### 🎓 Estrategia Universitaria (Spotify, YouTube, Gemini)
- **Selección Ponderada**: Utiliza una lista seleccionada de **45+ Universidades** (EE. UU., VN, JP, KR, etc.).
- **Seguimiento del Éxito**: Las universidades con tasas de éxito más altas se seleccionan con más frecuencia.
- **Generación de Documentos**: Genera tarjetas de identificación de estudiantes realistas con nombres y fechas dinámicos.

#### 👨‍🏫 Estrategia Docente (Bolt.new)
- **Segmentación por Edad**: Genera identidades mayores (25-55 años) para coincidir con la demografía de los profesores.
- **Generación de Documentos**: Crea "Certificados de Empleo" en lugar de identificaciones de estudiantes.
- **Endpoint**: Apunta a `collectTeacherPersonalInfo` en lugar de endpoints de estudiantes.

#### 🏫 Estrategia K12 (ChatGPT Plus)
- **Segmentación por Tipo de Escuela**: Apunta específicamente a escuelas con `type: "K12"` (no `HIGH_SCHOOL`).
- **Lógica de Aprobación Automática (Auto-Pass)**: La verificación K12 a menudo se **aprueba automáticamente** sin cargar documentos si la información de la escuela y el profesor coinciden.
- **Respaldo**: Si se requiere carga, genera una Insignia de Profesor.

#### 🎖️ Estrategia de Veteranos (ChatGPT Plus)
- **Elegibilidad Estricta**: Apunta a militares en servicio activo o veteranos separados dentro de los **últimos 12 meses**.
- **Verificación Autorizada**: SheerID verifica contra la base de datos DoD/DEERS.
- **Lógica**: Utiliza por defecto fechas de baja recientes para maximizar las posibilidades de aprobación automática.

#### 🛡️ Módulo Anti-Detección
Todas las herramientas ahora incluyen `anti_detect.py` que proporciona:
- **User-Agents Aleatorios**: 10+ cadenas UA de navegadores reales (Chrome, Firefox, Edge, Safari)
- **Encabezados Tipo Navegador**: `sec-ch-ua`, `Accept-Language` apropiados, etc.
- **Suplantación de Huella TLS**: Usa `curl_cffi` para imitar la huella JA3/JA4 de Chrome
- **Retrasos Aleatorios**: Temporización de distribución gamma para imitar comportamiento humano
- **Sesión Inteligente**: Selecciona automáticamente la mejor biblioteca HTTP disponible (curl_cffi > cloudscraper > httpx > requests)
- **Encabezados NewRelic**: Encabezados de seguimiento requeridos para llamadas a la API de SheerID
- **Calentamiento de Sesión**: Solicitudes previas a la verificación para establecer una sesión de navegador legítima
- **Generación de Email**: Crea emails de estudiantes realistas que coinciden con dominios universitarios
- **Coincidencia Geográfica de Proxy**: Coincide la ubicación del proxy con el país de la universidad para consistencia
- **Suplantación Multi-Navegador**: Rota entre huellas de Chrome, Edge y Safari

#### 📄 Módulo de Generación de Documentos
El nuevo `doc_generator.py` proporciona anti-detección para documentos generados:
- **Inyección de Ruido**: Ruido de píxeles aleatorio para evitar la detección de plantillas
- **Variación de Color**: 6 esquemas de colores diferentes para unicidad
- **Posicionamiento Dinámico**: Varianza de ±3px en las posiciones de los elementos
- **Múltiples Tipos**: ID de estudiante, Transcripción, Insignia de profesor
- **Detalles Realistas**: Códigos de barras, códigos QR, calificaciones de cursos aleatorios

> [!WARNING]
> **Las Herramientas Basadas en API Tienen Limitaciones Inherentes**
>
> SheerID utiliza detección avanzada que incluye:
> - **Huella TLS**: Python `requests`/`httpx` tienen firmas detectables
> - **Inteligencia de Señales**: Dirección IP, atributos del dispositivo, análisis de antigüedad del email
> - **Revisión de Documentos por IA**: Detecta documentos falsificados/de plantilla
>
> Para mejores resultados: Use **proxies residenciales** + instale `curl_cffi` para suplantación TLS.
> Las extensiones de navegador generalmente tienen tasas de éxito más altas que las herramientas API.

> [!IMPORTANT]
> **Gemini/Google One es SOLO EE.UU. (desde enero 2026)**
>
> El `one-verify-tool` solo funciona con IPs de EE.UU. Los usuarios internacionales verán fallos de verificación.

---

## 📋 Inicio Rápido

### Requisitos previos
- Python 3.8+
- `pip`

### Instalación

1.  **Clonar el repositorio:**
    ```bash
    git clone https://github.com/ThanhNguyxn/SheerID-Verification-Tool.git
    cd SheerID-Verification-Tool
    ```

2.  **Instalar dependencias:**
    ```bash
    pip install httpx Pillow
    ```

3.  **[Opcional] Anti-Detección Mejorada:**
    ```bash
    pip install curl_cffi cloudscraper
    ```
    - `curl_cffi`: Suplanta la huella TLS (JA3/JA4) para parecer Chrome real
    - `cloudscraper`: Evita la protección de Cloudflare

4.  **Ejecutar una herramienta (ej. Spotify):**
    ```bash
    cd spotify-verify-tool
    python main.py "YOUR_SHEERID_URL"
    ```

---

## 🦊 Socio Oficial: RoxyBrowser

🛡 **Protección Anti-Detección** — Huella digital única para cada cuenta, parecen dispositivos reales diferentes.

📉 **Prevenir Vinculación** — Impide que SheerID y las plataformas vinculen sus cuentas.

🚀 **Ideal para Usuarios Masivos** — Gestione de forma segura cientos de cuentas verificadas.

[![Prueba Gratis](https://img.shields.io/badge/Prueba%20Gratis-RoxyBrowser-ff6b35?style=for-the-badge&logo=googlechrome&logoColor=white)](https://roxybrowser.com?code=01045PFA)

---

## ⚠️ Descargo de Responsabilidad

Este proyecto es solo para **fines educativos**. Las herramientas demuestran cómo funcionan los sistemas de verificación y cómo se pueden probar.
- No utilizar para fines fraudulentos.
- Los autores no son responsables de ningún mal uso.
- Respete los Términos de Servicio de todas las plataformas.

---

## 🤝 Contribuir

¡Las contribuciones son bienvenidas! No dude en enviar una Pull Request.

---

## ❤️ Apoyo

Si encuentras útil este proyecto, considera apoyarme:

[![GitHub Sponsors](https://img.shields.io/badge/Sponsor-GitHub-ea4aaa?style=for-the-badge&logo=github)](https://github.com/sponsors/ThanhNguyxn)
[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-FFDD00?style=for-the-badge&logo=buy-me-a-coffee&logoColor=black)](https://buymeacoffee.com/thanhnguyxn)

---

## 🌐 Idiomas

| 🇺🇸 [English](../README.md) | 🇻🇳 [Tiếng Việt](./README.vi.md) | 🇨🇳 [中文](./README.zh.md) | 🇯🇵 [日本語](./README.ja.md) | 🇰🇷 [한국어](./README.ko.md) |
|:---:|:---:|:---:|:---:|:---:|
| 🇪🇸 [Español](./README.es.md) | 🇫🇷 [Français](./README.fr.md) | 🇩🇪 [Deutsch](./README.de.md) | 🇧🇷 [Português](./README.pt-BR.md) | 🇷🇺 [Русский](./README.ru.md) |
| 🇸🇦 [العربية](./README.ar.md) | 🇮🇳 [हिन्दी](./README.hi.md) | 🇹🇭 [ไทย](./README.th.md) | 🇹🇷 [Türkçe](./README.tr.md) | 🇵🇱 [Polski](./README.pl.md) |
| 🇮🇹 [Italiano](./README.it.md) | 🇮🇩 [Bahasa Indonesia](./README.id.md) | | | |
